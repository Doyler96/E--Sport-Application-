/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eteamsoftware;

/**
 *
 * @author Agnes
 */
public class ETeamApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ETeamWelcomeGUI myGUI = new ETeamWelcomeGUI();
        myGUI.setVisible(true);
        ETeamAdminGUI adminGUI = new ETeamAdminGUI();
        //adminGUI.setVisible(false);
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eteamsoftware;

import java.io.Serializable;

/**
 *
 * @author Agnes
 */
public class Member extends User implements Serializable{

    protected String hero;

    public Member() {
        super();
        hero = new String();
    }

    public Member(String email, String password, String name, String hero) {
        super(email, password, name);
        this.hero = hero;
    }

    public String getHero() {
        return hero;
    }

    public void setHero(String hero) {
        this.hero = hero;
    }

}

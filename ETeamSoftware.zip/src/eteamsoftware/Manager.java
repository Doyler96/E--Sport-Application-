/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eteamsoftware;

import java.io.Serializable;

/**
 *
 * @author Agnes
 */
public class Manager extends User implements Serializable {

    protected String[][] team;

    public Manager() {
        super();
        team = new String[5][2];
    }

    public Manager(String email, String password, String name, String[][] team) {
        super(email, password, name);
        this.team = team;
    }

    public String[][] getTeam() {
        return team;
    }

    public void setTeam(String[][] team) {
        this.team = team;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eteamsoftware;

/**
 *
 * @author Agnes
 */
public class DataPassing {
    public static String userEmail;

    public static String getUserEmail() {
        return userEmail;
    }

    public static void setUserEmail(String userEmail) {
        DataPassing.userEmail = userEmail;
    }

  
    
    
}

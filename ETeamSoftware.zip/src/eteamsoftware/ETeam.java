/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eteamsoftware;

import java.io.Serializable;

/**
 *
 * @author Agnes
 */
public class ETeam implements Serializable{
    protected String email;
    protected String password;
    protected String uEmail;
    protected String uPass;
    
    
}
